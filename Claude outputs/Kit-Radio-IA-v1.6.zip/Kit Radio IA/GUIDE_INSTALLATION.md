# Kit Radio IA — Guide d'installation

*Autres langues : [English](GUIDE_INSTALLATION_EN.md) · [Español](GUIDE_INSTALLATION_ES.md)*

Ce kit génère automatiquement, chaque jour, le contenu audio de votre radio
(météo, actualités, prières, sermon, témoignages, journal du soir, sweepers)
grâce à l'IA, et l'intègre à votre logiciel de diffusion pour une émission
100% automatisée.

Textes générés par **Claude** (Anthropic). Voix au choix : **Edge TTS**
(Microsoft, gratuit — recommandé), **ElevenLabs** (payant, qualité premium)
ou **Gemini** (Google, payant au-delà du quota gratuit). Fonctionne dans
toute langue supportée par le fournisseur de voix choisi (voir
`LANGUES_DISPONIBLES.md`).

**Compatible avec n'importe quel logiciel de diffusion** qui sait intégrer
automatiquement de nouveaux fichiers audio à une catégorie/rotation :
RadioDJ, RadioBOSS, SAM Broadcaster, ZaraRadio, ou autre. Le kit dépose les
fichiers audio dans des dossiers ; c'est votre logiciel qui les diffuse.

Temps d'installation estimé : 45 à 90 minutes la première fois.

---

## 1. Prérequis

- Windows 10 ou 11
- Un logiciel de diffusion déjà installé et fonctionnel, avec une
  bibliothèque musicale importée (voir section 6 pour les logiciels
  pris en charge)
- [Python 3.11 ou 3.12](https://www.python.org/downloads/) installé
  (cocher "Add python.exe to PATH" pendant l'installation)
- Une connexion Internet stable sur l'ordinateur qui diffuse

## 2. Votre clé de licence (obligatoire)

Vous avez reçu une clé de licence unique par email lors de votre achat.
Collez-la dans `config.py` (`LICENSE_KEY`) — voir section 5. Le kit
l'active automatiquement au premier lancement. Une licence est valable
pour un nombre limité de postes (voir votre confirmation d'achat) ; en cas
de coupure Internet, le kit continue de fonctionner jusqu'à 7 jours grâce
à une vérification mise en cache.

## 3. Obtenir vos clés API

1. **Claude (obligatoire, génération de texte)** : créez une clé sur
   https://console.anthropic.com/settings/keys. Coût très faible (modèle
   Haiku) — quelques centimes par jour pour une station.
2. **OpenWeatherMap (obligatoire, météo)** : créez une clé gratuite sur
   https://openweathermap.org/api
3. **Voix — un seul choix nécessaire** :
   - **Edge TTS** : rien à faire, c'est gratuit et déjà inclus.
   - **ElevenLabs** (optionnel, payant) : clé sur
     https://elevenlabs.io/app/settings/api-keys
   - **Gemini** (optionnel, payant) : clé sur https://aistudio.google.com/apikey

## 4. Installer les dépendances Python

1. Copiez le dossier `Kit Radio IA` à l'endroit où il vivra en permanence
   (ex: `C:\RadioIA\`)
2. Ouvrez une invite de commandes dans ce dossier (clic droit > "Ouvrir dans
   le terminal")
3. Installez les dépendances :

   ```
   pip install -r requirements.txt
   ```

   Si vous choisissez ElevenLabs ou Gemini comme voix, aucune dépendance
   supplémentaire n'est nécessaire (ElevenLabs utilise `requests`, déjà
   installé) — sauf pour Gemini : `pip install google-genai`.
   Si vous n'utilisez PAS RadioDJ, vous pouvez retirer `mysql-connector-python`
   de `requirements.txt` (uniquement utile pour `radiodj_request.py`).

## 5. Personnaliser `config.py`

Ouvrez `config.py` avec le Bloc-notes ou VS Code. C'est le SEUL fichier à
modifier. Remplissez chaque section, dans l'ordre :

0bis. **Clé de licence** (`LICENSE_KEY`) : collez la clé reçue à l'achat
    (voir section 2).
0. **Modules actifs** (`MODULES_ACTIFS`) : le kit inclut TOUT le contenu
   possible (météo, prières, témoignage, sermon, résumés d'actualités,
   journal du soir, sweepers). Mettez `False` sur ce que vous ne voulez PAS
   diffuser — par exemple une radio généraliste peut désactiver
   `"prieres"`, `"temoignage"` et `"sermon"` et ne garder que météo +
   actualités ; une radio confessionnelle garde tout actif. Un module
   désactivé ne fait AUCUN appel API et ne coûte rien.
1. **Identité** : nom de la station, langue, communauté/pays
2. **Géographie** : ville principale (format `"Ville,CODE_PAYS"` — voir
   codes ISO pays), ville diaspora optionnelle
3. **Clé Claude** (`ANTHROPIC_API_KEY`)
4. **Clé météo** (`OWM_API_KEY`)
5. **Moteur de voix** : `TTS_PROVIDER = "edge"` (par défaut, gratuit),
   `"elevenlabs"` ou `"gemini"`. Complétez la clé et les voix par rôle
   correspondantes uniquement pour le fournisseur choisi. Voir
   `LANGUES_DISPONIBLES.md` pour la liste des langues/voix disponibles.
6. **Prières par jour** (`PRIERE_MOMENTS`) : listez autant de moments que
   vous voulez, ex: `["matin", "soir"]` ou `["matin", "midi", "soir"]`
7. **Sources d'actualités** : ajoutez vos flux RSS par catégorie. Vous
   pouvez aussi créer vos propres catégories de A à Z (nom libre, ex:
   "business", "politique", "diaspora") avec vos propres sources de
   référence — un modèle à copier-coller est fourni directement dans
   `config.py`. Testez chaque lien dans un navigateur avant de l'ajouter —
   il doit afficher du XML
8. **Horaire** : ajustez les heures des scripts orchestrateurs
9. **Logiciel de diffusion** (`LOGICIEL_DIFFUSION`) : indiquez
   `"radiodj"`, `"radioboss"`, `"sam_broadcaster"`, `"zara"` ou `"autre"`
10. **RadioDJ** (uniquement si applicable) : base de données, mot de passe
    MySQL, port REST
11. **Dossiers de diffusion** (`DOSSIERS_DIFFUSION`) — voir étape 5

## 6. Configurer votre logiciel de diffusion

### Comment fonctionne le remplacement automatique

Chaque dossier de `DOSSIERS_DIFFUSION` contient **toujours un seul fichier**,
avec un nom fixe (ex. `meteo.mp3`, `bulletin_soir.mp3`). À chaque nouvelle
génération, ce fichier est **automatiquement remplacé** par le contenu du
jour — vous n'avez rien à supprimer manuellement, et il est tout à fait
normal de ne jamais voir plusieurs fichiers s'accumuler dans ces dossiers
(sauf `Sweepers`, qui contient un petit lot renouvelé périodiquement). Ce
n'est pas un bug si le dossier semble "ne pas se remplir" : c'est le
fonctionnement voulu. Configurez donc votre logiciel de diffusion pour
toujours lire ce fichier unique à l'heure programmée, plutôt que
d'imaginer une longue liste de pistes qui grandit avec le temps.

Le principe est **le même pour tous les logiciels** : le kit dépose un
fichier audio dans un dossier ; vous configurez ce dossier comme catégorie
ou rotation dans votre logiciel, qui l'intègre automatiquement à l'antenne.
Créez les dossiers listés dans `DOSSIERS_DIFFUSION` (météo, prières, sermon,
témoignage, résumés d'actualités, sweepers) à l'intérieur du dossier de votre
station, puis configurez-les selon votre logiciel :

### RadioDJ
1. **Base de données** : Options > Database. Notez host, port, nom de la
   base, utilisateur, mot de passe → dans `config.py` (`RADIODJ_DB`).
2. **API REST** (facultatif, pour les demandes d'auditeurs) : Options > REST
   API. Notez le port (8080 par défaut) et le mot de passe.
3. **Dossiers de catégories** : onglet Library, créez les catégories
   correspondant à `DOSSIERS_DIFFUSION`, puis ajoutez-les comme Events
   programmés (Tools > Event Scheduler) pour qu'AutoDJ les diffuse aux
   heures voulues.

### RadioBOSS
1. Ajoutez chaque dossier de `DOSSIERS_DIFFUSION` comme dossier de
   bibliothèque musicale (Tools > Music Library).
2. Activez la mise à jour automatique de la bibliothèque : programmez une
   tâche "Schedule automatic library update" qui scanne ces dossiers à
   intervalle régulier, pour que les nouveaux fichiers soient ajoutés
   automatiquement.
3. Créez une rotation/playlist par catégorie et programmez sa diffusion aux
   heures voulues (Scheduler intégré de RadioBOSS).

### SAM Broadcaster
1. Importez le contenu de chaque dossier dans SAM Broadcaster (Library >
   Import), en assignant le type de média approprié (ex: "News", "Station
   ID" pour les sweepers).
2. Organisez chaque type en playlist dédiée (ex: "Météo du jour", "Sermon du
   jour") et programmez leur diffusion via le planificateur de SAM.
3. SAM Broadcaster n'a pas de surveillance automatique de dossier native
   confirmée dans sa documentation — prévoyez un import manuel ou automatisé
   par script si vous voulez éviter cette étape (nous pouvons vous aider,
   contactez le support).

### ZaraRadio / ZaraStudio
1. Placez les dossiers de `DOSSIERS_DIFFUSION` dans une source audio de type
   "pistes aléatoires" (Random tracks) — ZaraStudio détecte automatiquement
   les nouveaux fichiers ajoutés à ces dossiers.
2. Pour de meilleures performances, utilisez des dossiers locaux (pas de
   partage réseau) et gardez le nombre de fichiers par dossier raisonnable.
3. Programmez la diffusion de chaque catégorie selon l'horloge de
   programmation de ZaraRadio.

### Autre logiciel
La plupart des logiciels de diffusion (y compris les solutions cloud comme
AzuraCast) offrent un mécanisme de dossier surveillé, d'import automatique
de playlist, ou une API. Consultez la documentation de votre logiciel pour
« watched folder », « auto import » ou « dossier surveillé ». Le kit fait sa
part (déposer les fichiers) quel que soit le logiciel en aval.

## 7. Premier test manuel

Testez chaque étape avant d'automatiser :

```
python fetch_weather.py
python fetch_news.py
python generate_content.py
python generate_sermon.py
python generate_daily_audio.py
python generate_resumes.py
python generate_bulletin_soir.py
python generate_sweepers.py
```

Chaque script affiche sa progression. Écoutez les fichiers audio produits
(dans `audio/`) pour valider ton et qualité.

## 8. Synchroniser avec votre logiciel de diffusion

```
python sync_diffusion.py
```

Copie les derniers audios du jour vers les dossiers configurés dans
`DOSSIERS_DIFFUSION` (les sweepers sont copiés directement par
`generate_sweepers.py`). Vérifiez ensuite dans votre logiciel que les
fichiers apparaissent bien dans la bibliothèque/rotation.

## 9. Automatiser avec le Planificateur de tâches Windows

```
installer_taches.bat
```

(clic droit > "Exécuter en tant qu'administrateur" pour une installation
SYSTEM — sinon les tâches tournent pour l'utilisateur courant, ce qui
fonctionne aussi tant que la session reste ouverte).

Ce script crée une tâche par entrée de `config.HORAIRE`, chacune lançant un
orchestrateur (`run_meteo.py`, `run_spirituel.py`, `run_news.py`,
`run_bulletin_soir.py`, `run_sweepers.py`) qui génère le contenu **et**
synchronise vers votre logiciel de diffusion automatiquement — un seul
aller-retour au Planificateur de tâches suffit par segment.

## 10. Demandes d'auditeurs (optionnel, RadioDJ uniquement)

`radiodj_request.py` cherche une chanson dans votre bibliothèque RadioDJ et
l'ajoute à la file de lecture — utile pour un chatbot de demandes ou une
interface web branchée par-dessus. Cette fonctionnalité est spécifique à
RadioDJ (base de données + API REST) ; elle ne s'applique pas aux autres
logiciels.

## 11. Changer de fournisseur de voix plus tard

Modifiez simplement `TTS_PROVIDER` dans `config.py` et complétez la clé/les
voix du nouveau fournisseur — aucun autre fichier à toucher. Les prochains
audios générés utiliseront automatiquement la nouvelle voix (les anciens
fichiers déjà générés ne sont pas régénérés).

## 12. Annexe — exemple complet de `config.py` rempli

Voici à quoi ressemble un `config.py` entièrement rempli, pour une station
fictive nommée « Radio Espoir Vivant » (chrétienne, Haïti + diaspora à
Montréal). Servez-vous-en comme modèle si vous êtes perdu — remplacez
simplement chaque valeur par celle de votre propre station.

```python
# ------------------------------------------------------
# LICENCE
# ------------------------------------------------------
LICENSE_KEY = "KRIA-7F3D-9K2M-QX81"   # votre vraie clé vient de l'email d'achat
LICENCE_REQUISE = True
LICENCE_GRACE_JOURS = 7

# ------------------------------------------------------
# 0. MODULES ACTIFS
# ------------------------------------------------------
MODULES_ACTIFS = {
    "meteo":         True,
    "prieres":       True,
    "temoignage":    True,
    "sermon":        True,
    "news_resumes":  True,
    "bulletin_soir": True,
    "sweepers":      True,
}

# ------------------------------------------------------
# 1. IDENTITÉ DE LA STATION
# ------------------------------------------------------
STATION_NOM = "Radio Espoir Vivant"
STATION_SLOGAN = "La voix de l'espérance"
STATION_LANGUE = "français"
PAYS_OU_COMMUNAUTE = "Haïti"
NOM_DIASPORA = "la diaspora haïtienne à Montréal"

# ------------------------------------------------------
# 2. GÉOGRAPHIE
# ------------------------------------------------------
VILLE_PRINCIPALE = {"owm_query": "Port-au-Prince,HT", "label": "Port-au-Prince, Haïti"}
VILLE_DIASPORA = {"owm_query": "Montreal,CA", "label": "Montréal, Canada"}

# ------------------------------------------------------
# 3. CLÉ API — TEXTE (Claude)
# ------------------------------------------------------
ANTHROPIC_API_KEY = "sk-ant-VOTRE-VRAIE-CLE-ANTHROPIC-ICI"
CLAUDE_MODEL = "claude-haiku-4-5-20251001"

# ------------------------------------------------------
# 4. CLÉ API — MÉTÉO
# ------------------------------------------------------
OWM_API_KEY = "votre-cle-openweathermap-gratuite-ici"

# ------------------------------------------------------
# 5. MOTEUR DE VOIX (TTS)
# ------------------------------------------------------
TTS_PROVIDER = "edge"
VOIX_ROLES = ["presentateur_a", "presentateur_b", "priere", "sermon", "temoignage", "meteo"]
EDGE_VOICES = {
    "presentateur_a": "fr-CA-AntoineNeural",
    "presentateur_b": "fr-CA-SylvieNeural",
    "priere":         "fr-CA-SylvieNeural",
    "sermon":         "fr-FR-HenriNeural",
    "temoignage":     "fr-FR-DeniseNeural",
    "meteo":          "fr-CA-AntoineNeural",
}

# ------------------------------------------------------
# 6. PRIÈRES
# ------------------------------------------------------
PRIERE_MOMENTS = ["matin", "soir"]

# ------------------------------------------------------
# 7. SOURCES D'ACTUALITÉS
# ------------------------------------------------------
CATEGORIES_NEWS = {
    "chretien": {
        "label": "actualités chrétiennes",
        "presentateur": "presentateur_a",
        "flux": [
            {"url": "https://morningstarnews.org/feed/", "source": "Morning Star News"},
            {"url": "https://www.porteouverte.org/feed/", "source": "Porte Ouverte"},
        ],
    },
    "monde": {
        "label": "actualités internationales",
        "presentateur": "presentateur_b",
        "flux": [
            {"url": "https://www.france24.com/fr/rss", "source": "France 24"},
        ],
    },
    "haiti": {
        "label": "actualités d'Haïti",
        "presentateur": "presentateur_a",
        "flux": [
            {"url": "https://www.lenouvelliste.com/rss", "source": "Le Nouvelliste"},
        ],
    },
}

# ------------------------------------------------------
# 8. HORAIRE
# ------------------------------------------------------
HORAIRE = {
    (6, 0):         "run_meteo.py",
    (7, 0):         "run_spirituel.py",
    (15, 0):        "run_news.py",
    (18, 0):        "run_bulletin_soir.py",
    (4, 30, "MON"): "run_sweepers.py",
}

# ------------------------------------------------------
# 9. SWEEPERS / STATION ID
# ------------------------------------------------------
SWEEPER_TAILLE_LOT = 3

# ------------------------------------------------------
# 10. LOGICIEL DE DIFFUSION
# ------------------------------------------------------
LOGICIEL_DIFFUSION = "radiodj"

# ------------------------------------------------------
# 10bis. RADIODJ (optionnel, RadioDJ uniquement)
# ------------------------------------------------------
RADIODJ_DB = {
    "host": "127.0.0.1",
    "port": 3306,
    "database": "radiodj2050EspoirVivant",
    "user": "root",
    "password": "votre-mot-de-passe-mysql-ici",
}
RADIODJ_REST_HOST = "http://localhost:8080"
RADIODJ_REST_AUTH = "changeme"

# ------------------------------------------------------
# 11. DOSSIERS DE DIFFUSION
# ------------------------------------------------------
DOSSIERS_DIFFUSION = {
    "meteo":           "Nouvelles/Meteo",
    "priere_matin":    "Priere/Priere du matin",
    "priere_soir":     "Priere/Priere du soir",
    "temoignage":      "Priere/Temoignage",
    "sermon":          "Sermon",
    "bulletin_soir":   "Nouvelles/Bulletin du Soir",
    "resume_chretien": "Nouvelles/Resume Chretien",
    "resume_monde":    "Nouvelles/Resume Monde",
    "resume_haiti":    "Nouvelles/Resume Haiti",
    "sweepers":        "Nouvelles/Sweepers",
}
```

## 13. Dépannage

- **"LICENCE KIT RADIO IA — BLOCAGE"** : vérifiez que `LICENSE_KEY` dans
  `config.py` contient bien la clé reçue par email, sans espace ni
  guillemets en trop. Si le message parle d'une limite d'activations
  atteinte, contactez le support (la licence est peut-être déjà active sur
  un autre poste). Une coupure Internet passagère ne bloque pas
  immédiatement — le kit tolère jusqu'à 7 jours hors ligne.
- **"config.py incomplet"** : une clé obligatoire n'a pas été remplie
  (Claude, ou la clé du fournisseur de voix choisi).
- **Aucun article récupéré** : vérifiez vos flux RSS un par un dans un
  navigateur.
- **Erreur RadioDJ** : vérifiez host/port/utilisateur/mot de passe dans
  `config.py`, et que le service MySQL de RadioDJ tourne.
- **Les fichiers n'apparaissent pas dans mon logiciel** : vérifiez que le
  dossier configuré dans `DOSSIERS_DIFFUSION` correspond exactement au
  dossier surveillé/importé par votre logiciel (voir section 6), et forcez
  un scan/rafraîchissement manuel de la bibliothèque.
- **Tâche planifiée qui ne se déclenche pas** : relancez
  `installer_taches.bat` en administrateur, ou vérifiez dans le
  Planificateur de tâches Windows (`taskschd.msc`).
- **Fichier audio illisible** : si vous utilisez Gemini comme voix, les
  fichiers sont en `.wav` (pas `.mp3`) — assurez-vous que votre logiciel de
  diffusion accepte le WAV dans cette catégorie (c'est le cas par défaut
  pour la plupart des logiciels).

---

Besoin d'aide pour l'installation ou la personnalisation ? Contactez le
support inclus avec votre achat.
