# Kit Radio IA — Guía de instalación (Español)

*Otros idiomas: [Français](GUIDE_INSTALLATION.md) · [English](GUIDE_INSTALLATION_EN.md)*

> © 2026 Souvenan Garçon — Kit Radio IA. Todos los derechos reservados. Este producto está protegido por derechos de autor; la reproducción, reventa o redistribución sin autorización está prohibida. Consulte `LICENCE_EULA.md` para conocer los términos completos de la licencia.

Este kit genera automáticamente, cada día, el contenido de audio de su
radio (clima, noticias, oraciones, sermón, testimonios, boletín de la
noche, cortinas/sweepers) mediante IA, y lo integra a su software de
transmisión para una emisión 100% automatizada.

Textos generados por **Claude** (Anthropic). Elija su motor de voz:
**Edge TTS** (Microsoft, gratis — recomendado), **ElevenLabs** (de pago,
calidad premium) o **Gemini** (Google, de pago más allá de la cuota
gratuita). Funciona en cualquier idioma compatible con el proveedor de voz
elegido (ver `LANGUES_DISPONIBLES.md`).

**Compatible con cualquier software de transmisión** que pueda incorporar
automáticamente nuevos archivos de audio a una categoría o rotación:
RadioDJ, RadioBOSS, SAM Broadcaster, ZaraRadio u otros. El kit coloca los
archivos de audio en carpetas; su software los transmite al aire.

Tiempo estimado de instalación: 45 a 90 minutos la primera vez.

---

## 1. Requisitos previos

- Windows 10 u 11
- Software de transmisión ya instalado y funcionando, con una biblioteca
  musical importada (ver sección 6 para el software compatible)
- [Python 3.11 o 3.12](https://www.python.org/downloads/) instalado
  (marque "Add python.exe to PATH" durante la instalación)
- Una conexión a Internet estable en el equipo que transmite

## 2. Su clave de licencia (obligatoria)

Recibió una clave de licencia única por correo electrónico al comprar el
kit. Péguela en `config.py` (`LICENSE_KEY`) — ver sección 5. El kit la
activa automáticamente en el primer arranque. Una licencia es válida para
un número limitado de equipos (ver su confirmación de compra); si se
corta Internet, el kit sigue funcionando hasta 7 días gracias a una
verificación en caché.

## 3. Obtener sus claves API

1. **Claude (obligatoria, generación de texto)**: cree una clave en
   https://console.anthropic.com/settings/keys. Costo muy bajo (modelo
   Haiku) — unos centavos al día para una estación.
2. **OpenWeatherMap (obligatoria, clima)**: cree una clave gratuita en
   https://openweathermap.org/api
3. **Voz — solo se necesita una opción**:
   - **Edge TTS**: no hay nada que hacer, es gratis y ya está incluido.
   - **ElevenLabs** (opcional, de pago): clave en
     https://elevenlabs.io/app/settings/api-keys
   - **Gemini** (opcional, de pago): clave en
     https://aistudio.google.com/apikey

## 4. Instalar las dependencias de Python

1. Copie la carpeta `Kit Radio IA` al lugar donde vivirá permanentemente
   (ej: `C:\RadioIA\`)
2. Abra una ventana de comandos en esa carpeta (clic derecho > "Abrir en
   la terminal")
3. Instale las dependencias:

   ```
   pip install -r requirements.txt
   ```

   Si elige ElevenLabs o Gemini como voz, no necesita ninguna dependencia
   adicional para ElevenLabs (usa `requests`, ya instalado) — excepto para
   Gemini: `pip install google-genai`.
   Si NO usa RadioDJ, puede quitar `mysql-connector-python` de
   `requirements.txt` (solo lo usa `radiodj_request.py`).

## 5. Personalizar `config.py`

Abra `config.py` con el Bloc de notas o VS Code. Es el ÚNICO archivo que
debe modificar. Complete cada sección, en orden:

0bis. **Clave de licencia** (`LICENSE_KEY`): pegue la clave recibida al
    comprar (ver sección 2).
0. **Módulos activos** (`MODULES_ACTIFS`): el kit incluye TODO el contenido
   posible (clima, oraciones, testimonio, sermón, resúmenes de noticias,
   boletín de la noche, cortinas). Ponga `False` en lo que NO quiera al
   aire — por ejemplo, una estación generalista puede desactivar
   `"prieres"`, `"temoignage"` y `"sermon"` y quedarse solo con clima +
   noticias; una estación confesional mantiene todo activo. Un módulo
   desactivado no hace NINGUNA llamada a la API y no cuesta nada.
1. **Identidad**: nombre de la estación, idioma, país/comunidad
2. **Geografía**: ciudad principal (formato `"Ciudad,CÓDIGO_PAÍS"` —
   códigos ISO de país), ciudad de la diáspora opcional
3. **Clave de Claude** (`ANTHROPIC_API_KEY`)
4. **Clave del clima** (`OWM_API_KEY`)
5. **Motor de voz**: `TTS_PROVIDER = "edge"` (predeterminado, gratis),
   `"elevenlabs"` o `"gemini"`. Complete la clave y las voces por rol
   correspondientes solo para el proveedor elegido. Vea
   `LANGUES_DISPONIBLES.md` para la lista de idiomas/voces disponibles.
6. **Oraciones por día** (`PRIERE_MOMENTS`): liste tantos momentos como
   quiera, ej: `["mañana", "noche"]` o `["mañana", "mediodía", "noche"]`
7. **Fuentes de noticias**: agregue sus feeds RSS por categoría. También
   puede crear sus propias categorías desde cero (nombre libre, ej:
   "negocios", "política", "diáspora") con sus propias fuentes de
   referencia — hay una plantilla para copiar y pegar directamente en
   `config.py`. Pruebe cada enlace en un navegador antes de agregarlo —
   debe mostrar XML
8. **Horario**: ajuste las horas de los scripts orquestadores
9. **Software de transmisión** (`LOGICIEL_DIFFUSION`): indique
   `"radiodj"`, `"radioboss"`, `"sam_broadcaster"`, `"zara"` u `"autre"`
   (otro)
10. **RadioDJ** (solo si aplica): base de datos, contraseña MySQL, puerto
    REST
11. **Carpetas de transmisión** (`DOSSIERS_DIFFUSION`) — ver sección 6

## 6. Configurar su software de transmisión

### Cómo funciona el reemplazo automático

Cada carpeta de `DOSSIERS_DIFFUSION` contiene **siempre un solo archivo**,
con un nombre fijo (ej. `meteo.mp3`, `bulletin_soir.mp3`). Cada vez que se
genera contenido nuevo, ese archivo se **reemplaza automáticamente** por el
contenido del día — no necesita eliminar nada manualmente, y es
completamente normal no ver nunca varios archivos acumulándose en estas
carpetas (excepto `Sweepers`, que contiene un pequeño lote renovado
periódicamente). No es un error si una carpeta parece "no llenarse nunca"
— es el comportamiento esperado. Configure su software de transmisión para
que siempre reproduzca este único archivo a la hora programada, en lugar
de esperar una lista larga y creciente de pistas.

El principio es **el mismo para todos los programas**: el kit coloca un
archivo de audio en una carpeta; usted configura esa carpeta como
categoría o rotación en su software, que lo transmite automáticamente al
aire. Cree las carpetas listadas en `DOSSIERS_DIFFUSION` (clima, oraciones,
sermón, testimonio, resúmenes de noticias, cortinas) dentro de la carpeta
de su estación, y luego configúrelas según su software:

### RadioDJ
1. **Base de datos**: Options > Database. Anote host, puerto, nombre de la
   base, usuario, contraseña → en `config.py` (`RADIODJ_DB`).
2. **API REST** (opcional, para pedidos de oyentes): Options > REST API.
   Anote el puerto (8080 por defecto) y la contraseña.
3. **Carpetas de categorías**: pestaña Library, cree las categorías
   correspondientes a `DOSSIERS_DIFFUSION`, y agréguelas como Events
   programados (Tools > Event Scheduler) para que AutoDJ las transmita en
   los horarios deseados.

### RadioBOSS
1. Agregue cada carpeta de `DOSSIERS_DIFFUSION` como carpeta de la
   biblioteca musical (Tools > Music Library).
2. Active la actualización automática de la biblioteca: programe una
   tarea "Schedule automatic library update" que escanee esas carpetas a
   intervalos regulares, para que los nuevos archivos se agreguen
   automáticamente.
3. Cree una rotación/playlist por categoría y programe su transmisión
   (Scheduler integrado de RadioBOSS).

### SAM Broadcaster
1. Importe el contenido de cada carpeta a SAM Broadcaster (Library >
   Import), asignando el tipo de medio adecuado (ej: "News", "Station ID"
   para las cortinas).
2. Organice cada tipo en una playlist dedicada (ej: "Clima del día",
   "Sermón del día") y programe su transmisión mediante el planificador de
   SAM.
3. SAM Broadcaster no tiene una función confirmada de monitoreo automático
   de carpetas en su documentación — prevea una importación manual, o un
   script automatizado si desea evitar este paso (podemos ayudarle —
   contacte al soporte).

### ZaraRadio / ZaraStudio
1. Configure las carpetas de `DOSSIERS_DIFFUSION` como una fuente de audio
   de tipo "pistas aleatorias" (Random tracks) — ZaraStudio detecta
   automáticamente los nuevos archivos agregados a esas carpetas.
2. Para un mejor rendimiento, use carpetas locales (no comparticiones de
   red) y mantenga un número razonable de archivos por carpeta.
3. Programe la transmisión de cada categoría según el reloj de
   programación de ZaraRadio.

### Otro software
La mayoría de los programas de transmisión (incluidas soluciones en la
nube como AzuraCast) ofrecen un mecanismo de carpeta vigilada, importación
automática de playlist, o una API. Consulte la documentación de su
software buscando "watched folder" o "auto import". El kit hace su parte
(colocar los archivos) sin importar el software que use después.

## 7. Primera prueba manual

Pruebe cada paso antes de automatizar:

```
python fetch_weather.py
python fetch_news.py
python generate_content.py
python generate_sermon.py
python generate_daily_audio.py
python generate_resumes.py
python generate_bulletin_soir.py
python generate_sweepers.py
```

Cada script muestra su progreso. Escuche los archivos de audio generados
(en `audio/`) para validar el tono y la calidad.

## 8. Sincronizar con su software de transmisión

```
python sync_diffusion.py
```

Copia los últimos audios del día a las carpetas configuradas en
`DOSSIERS_DIFFUSION` (las cortinas se copian directamente mediante
`generate_sweepers.py`). Luego verifique en su software que los archivos
aparezcan en la biblioteca/rotación.

## 9. Automatizar con el Programador de tareas de Windows

```
installer_taches.bat
```

(clic derecho > "Ejecutar como administrador" para una instalación SYSTEM
— de lo contrario las tareas se ejecutan como el usuario actual, lo cual
también funciona mientras la sesión permanezca abierta).

Este script crea una tarea por cada entrada de `config.HORAIRE`, cada una
ejecutando un orquestador (`run_meteo.py`, `run_spirituel.py`,
`run_news.py`, `run_bulletin_soir.py`, `run_sweepers.py`) que genera el
contenido **y** lo sincroniza automáticamente con su software de
transmisión — basta una sola entrada en el Programador de tareas por
segmento.

## 10. Pedidos de canciones de oyentes (opcional, solo RadioDJ)

`radiodj_request.py` busca una canción en su biblioteca de RadioDJ y la
agrega a la cola de reproducción — útil para un chatbot de pedidos o una
interfaz web construida encima. Esta función es específica de RadioDJ
(base de datos + API REST); no aplica a otros programas.

## 11. Cambiar de proveedor de voz más adelante

Simplemente cambie `TTS_PROVIDER` en `config.py` y complete la clave/voces
del nuevo proveedor — no hay que tocar ningún otro archivo. Los próximos
audios generados usarán automáticamente la nueva voz (los archivos ya
generados no se regeneran).

## 12. Anexo — ejemplo completo de un `config.py` rellenado

Así se ve un `config.py` completamente rellenado, para una estación
ficticia llamada "Radio Espoir Vivant" (cristiana, Haití + diáspora en
Montreal). Úselo como plantilla si se siente perdido — solo reemplace cada
valor con la información de su propia estación.

```python
# ------------------------------------------------------
# LICENCIA
# ------------------------------------------------------
LICENSE_KEY = "KRIA-7F3D-9K2M-QX81"   # su clave real viene del correo de compra
LICENCE_REQUISE = True
LICENCE_GRACE_JOURS = 7

# ------------------------------------------------------
# 0. MÓDULOS ACTIVOS
# ------------------------------------------------------
MODULES_ACTIFS = {
    "meteo":         True,
    "prieres":       True,
    "temoignage":    True,
    "sermon":        True,
    "news_resumes":  True,
    "bulletin_soir": True,
    "sweepers":      True,
}

# ------------------------------------------------------
# 1. IDENTIDAD DE LA ESTACIÓN
# ------------------------------------------------------
STATION_NOM = "Radio Espoir Vivant"
STATION_SLOGAN = "La voix de l'espérance"
STATION_LANGUE = "français"
PAYS_OU_COMMUNAUTE = "Haïti"
NOM_DIASPORA = "la diaspora haïtienne à Montréal"

# ------------------------------------------------------
# 2. GEOGRAFÍA
# ------------------------------------------------------
VILLE_PRINCIPALE = {"owm_query": "Port-au-Prince,HT", "label": "Port-au-Prince, Haïti"}
VILLE_DIASPORA = {"owm_query": "Montreal,CA", "label": "Montréal, Canada"}

# ------------------------------------------------------
# 3. CLAVE API — TEXTO (Claude)
# ------------------------------------------------------
ANTHROPIC_API_KEY = "sk-ant-SU-CLAVE-REAL-DE-ANTHROPIC-AQUI"
CLAUDE_MODEL = "claude-haiku-4-5-20251001"

# ------------------------------------------------------
# 4. CLAVE API — CLIMA
# ------------------------------------------------------
OWM_API_KEY = "su-clave-gratuita-de-openweathermap-aqui"

# ------------------------------------------------------
# 5. MOTOR DE VOZ (TTS)
# ------------------------------------------------------
TTS_PROVIDER = "edge"
VOIX_ROLES = ["presentateur_a", "presentateur_b", "priere", "sermon", "temoignage", "meteo"]
EDGE_VOICES = {
    "presentateur_a": "fr-CA-AntoineNeural",
    "presentateur_b": "fr-CA-SylvieNeural",
    "priere":         "fr-CA-SylvieNeural",
    "sermon":         "fr-FR-HenriNeural",
    "temoignage":     "fr-FR-DeniseNeural",
    "meteo":          "fr-CA-AntoineNeural",
}

# ------------------------------------------------------
# 6. ORACIONES
# ------------------------------------------------------
PRIERE_MOMENTS = ["matin", "soir"]

# ------------------------------------------------------
# 7. FUENTES DE NOTICIAS
# ------------------------------------------------------
CATEGORIES_NEWS = {
    "chretien": {
        "label": "actualités chrétiennes",
        "presentateur": "presentateur_a",
        "flux": [
            {"url": "https://morningstarnews.org/feed/", "source": "Morning Star News"},
            {"url": "https://www.porteouverte.org/feed/", "source": "Porte Ouverte"},
        ],
    },
    "monde": {
        "label": "actualités internationales",
        "presentateur": "presentateur_b",
        "flux": [
            {"url": "https://www.france24.com/fr/rss", "source": "France 24"},
        ],
    },
    "haiti": {
        "label": "actualités d'Haïti",
        "presentateur": "presentateur_a",
        "flux": [
            {"url": "https://www.lenouvelliste.com/rss", "source": "Le Nouvelliste"},
        ],
    },
}

# ------------------------------------------------------
# 8. HORARIO
# ------------------------------------------------------
HORAIRE = {
    (6, 0):         "run_meteo.py",
    (7, 0):         "run_spirituel.py",
    (15, 0):        "run_news.py",
    (18, 0):        "run_bulletin_soir.py",
    (4, 30, "MON"): "run_sweepers.py",
}

# ------------------------------------------------------
# 9. SWEEPERS / IDENTIFICACIÓN DE LA ESTACIÓN
# ------------------------------------------------------
SWEEPER_TAILLE_LOT = 3

# ------------------------------------------------------
# 10. SOFTWARE DE TRANSMISIÓN
# ------------------------------------------------------
LOGICIEL_DIFFUSION = "radiodj"

# ------------------------------------------------------
# 10bis. RADIODJ (opcional, solo RadioDJ)
# ------------------------------------------------------
RADIODJ_DB = {
    "host": "127.0.0.1",
    "port": 3306,
    "database": "radiodj2050EspoirVivant",
    "user": "root",
    "password": "su-contraseña-mysql-aqui",
}
RADIODJ_REST_HOST = "http://localhost:8080"
RADIODJ_REST_AUTH = "changeme"

# ------------------------------------------------------
# 11. CARPETAS DE TRANSMISIÓN
# ------------------------------------------------------
DOSSIERS_DIFFUSION = {
    "meteo":           "Nouvelles/Meteo",
    "priere_matin":    "Priere/Priere du matin",
    "priere_soir":     "Priere/Priere du soir",
    "temoignage":      "Priere/Temoignage",
    "sermon":          "Sermon",
    "bulletin_soir":   "Nouvelles/Bulletin du Soir",
    "resume_chretien": "Nouvelles/Resume Chretien",
    "resume_monde":    "Nouvelles/Resume Monde",
    "resume_haiti":    "Nouvelles/Resume Haiti",
    "sweepers":        "Nouvelles/Sweepers",
}
```

## 13. Solución de problemas

- **"LICENCE KIT RADIO IA — BLOCAGE"**: verifique que `LICENSE_KEY` en
  `config.py` contenga exactamente la clave de su correo de compra, sin
  espacios ni comillas de más. Si el mensaje menciona un límite de
  activaciones, contacte al soporte (la licencia puede estar ya activa en
  otro equipo). Un corte breve de Internet no bloquea de inmediato — el
  kit tolera hasta 7 días sin conexión.
- **"config.py incompleto"**: falta completar una clave obligatoria
  (Claude, o la clave del proveedor de voz elegido).
- **No se obtuvo ningún artículo**: verifique cada feed RSS uno por uno en
  un navegador.
- **Error de RadioDJ**: verifique host/puerto/usuario/contraseña en
  `config.py`, y que el servicio MySQL de RadioDJ esté en ejecución.
- **Los archivos no aparecen en mi software**: asegúrese de que la carpeta
  configurada en `DOSSIERS_DIFFUSION` coincida exactamente con la carpeta
  vigilada/importada por su software (ver sección 6), y fuerce un
  escaneo/actualización manual de la biblioteca.
- **La tarea programada no se activa**: vuelva a ejecutar
  `installer_taches.bat` como administrador, o revise el Programador de
  tareas de Windows (`taskschd.msc`).
- **El archivo de audio no se reproduce**: si usa Gemini como voz, los
  archivos son `.wav` (no `.mp3`) — asegúrese de que su software de
  transmisión acepte WAV en esa categoría (así es por defecto en la
  mayoría de los programas).

---

¿Necesita ayuda con la instalación o la personalización? Contacte al
soporte incluido con su compra.
