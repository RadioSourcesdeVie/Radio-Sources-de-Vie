@echo off
cd /d "%~dp0"
python sync_diffusion.py
pause
