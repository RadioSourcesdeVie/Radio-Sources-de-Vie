#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kit Radio IA - Orchestrateur SWEEPERS : régénère le lot hebdomadaire/mensuel.
Désactivable entièrement via config.MODULES_ACTIFS["sweepers"] = False."""
from _orchestration_commune import log, lancer, actif

def main():
    log("SWEEPERS")
    if not actif("sweepers"):
        print("Sweepers désactivés (config.MODULES_ACTIFS) — étape ignorée")
        return
    lancer("generate_sweepers.py")
    print("Sweepers OK")

if __name__ == "__main__":
    main()
