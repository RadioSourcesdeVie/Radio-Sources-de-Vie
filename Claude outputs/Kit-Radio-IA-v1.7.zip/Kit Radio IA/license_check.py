# -*- coding: utf-8 -*-
"""
Kit Radio IA - Vérification de la licence (Lemon Squeezy License API)
Chaque vente génère automatiquement une clé de licence unique sur Lemon
Squeezy. Ce module l'active sur ce poste (1 seule fois) puis la revalide
périodiquement, pour limiter le nombre d'installations par licence achetée
(config.LICENCE_ACTIVATIONS_MAX, réglé côté Lemon Squeezy sur la fiche produit).

Fonctionnement :
- Premier lancement : active la clé (POST /v1/licenses/activate) et
  enregistre l'identifiant d'activation localement (.licence_cache.json).
- Lancements suivants : revalide la clé (POST /v1/licenses/validate).
- Hors ligne temporaire : réutilise la dernière vérification réussie
  pendant config.LICENCE_GRACE_JOURS jours, pour ne pas bloquer la
  diffusion à cause d'une simple coupure Internet passagère.
- Clé invalide, désactivée, expirée, ou limite d'activations atteinte :
  bloque l'exécution avec un message clair.

Peut être entièrement désactivé (usage interne, développement) avec
config.LICENCE_REQUISE = False.
"""
import sys
import json
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config

BASE_DIR = Path(__file__).parent.parent
CACHE_FILE = BASE_DIR / ".licence_cache.json"

ACTIVATE_URL = "https://api.lemonsqueezy.com/v1/licenses/activate"
VALIDATE_URL = "https://api.lemonsqueezy.com/v1/licenses/validate"


def _load_cache() -> dict:
    if CACHE_FILE.exists():
        try:
            return json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save_cache(data: dict):
    CACHE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _bloquer(message: str):
    print("\n" + "=" * 60)
    print("LICENCE KIT RADIO IA — BLOCAGE")
    print("=" * 60)
    print(message)
    print("Support : voir vos informations d'achat pour contacter le vendeur.")
    print("=" * 60 + "\n")
    sys.exit(1)


def verifier_licence():
    if not getattr(config, "LICENCE_REQUISE", True):
        return  # licence désactivée volontairement (usage interne / développement)

    key = getattr(config, "LICENSE_KEY", "")
    if not key or "COLLEZ_VOTRE" in key:
        _bloquer("Aucune clé de licence renseignée. Ouvrez config.py et collez la clé "
                 "reçue par email lors de votre achat dans LICENSE_KEY.")

    try:
        import requests
    except ImportError:
        _bloquer("Le module 'requests' est requis pour vérifier la licence "
                 "(pip install -r requirements.txt).")
        return

    cache = _load_cache()
    aujourd_hui = datetime.now()
    grace_jours = getattr(config, "LICENCE_GRACE_JOURS", 7)

    try:
        if not cache.get("instance_id"):
            import socket
            nom_instance = f"{config.STATION_NOM} - {socket.gethostname()}"
            resp = requests.post(ACTIVATE_URL, data={
                "license_key": key, "instance_name": nom_instance,
            }, timeout=10)
            data = resp.json()
            if not data.get("activated"):
                erreur = data.get("error") or "clé invalide ou limite d'activations atteinte"
                _bloquer(f"Activation refusée : {erreur}")
            cache = {"instance_id": data["instance"]["id"],
                     "derniere_verification_ok": aujourd_hui.strftime("%Y-%m-%d")}
            _save_cache(cache)
            print(f"Licence activée sur ce poste ({nom_instance}).")
        else:
            resp = requests.post(VALIDATE_URL, data={
                "license_key": key, "instance_id": cache["instance_id"],
            }, timeout=10)
            data = resp.json()
            if not data.get("valid"):
                statut = data.get("license_key", {}).get("status", "inconnu")
                _bloquer(f"Licence invalide (statut : {statut}). "
                         "Si vous pensez que c'est une erreur, contactez le support.")
            cache["derniere_verification_ok"] = aujourd_hui.strftime("%Y-%m-%d")
            _save_cache(cache)

    except requests.exceptions.RequestException:
        dernier_ok = cache.get("derniere_verification_ok")
        if dernier_ok:
            try:
                delta = aujourd_hui - datetime.strptime(dernier_ok, "%Y-%m-%d")
            except ValueError:
                delta = timedelta(days=grace_jours + 1)
            if delta.days <= grace_jours:
                print(f"Licence : vérification impossible (pas de connexion) — "
                      f"dernière vérification OK il y a {delta.days} jour(s), on continue.")
                return
        _bloquer("Impossible de vérifier la licence (pas de connexion Internet) "
                 "et aucune vérification récente en cache. Connectez cet ordinateur "
                 "à Internet puis relancez.")
