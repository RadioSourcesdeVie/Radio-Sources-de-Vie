#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kit Radio IA - Orchestrateur MÉTÉO : récupère la météo, génère l'audio, synchronise vers la diffusion.
Désactivable entièrement via config.MODULES_ACTIFS["meteo"] = False."""
from _orchestration_commune import log, lancer, actif

def main():
    log("METEO")
    if not actif("meteo"):
        print("Météo désactivée (config.MODULES_ACTIFS) — étape ignorée")
        return
    lancer("fetch_weather.py")
    lancer("generate_daily_audio.py")
    lancer("sync_diffusion.py")
    print("Météo OK")

if __name__ == "__main__":
    main()
