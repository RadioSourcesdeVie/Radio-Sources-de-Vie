#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kit Radio IA - Orchestrateur JOURNAL DU SOIR : réutilise les news du jour, génère le bulletin + synchronisation diffusion.
Désactivable entièrement via config.MODULES_ACTIFS["bulletin_soir"] = False.
Fonctionne même si config.MODULES_ACTIFS["news_resumes"] est désactivé (relance
fetch_news.py lui-même si besoin, sans dépendre de run_news.py)."""
from _orchestration_commune import log, lancer, actif

def main():
    log("BULLETIN_SOIR")
    if not actif("bulletin_soir"):
        print("Journal du soir désactivé (config.MODULES_ACTIFS) — étape ignorée")
        return
    lancer("fetch_news.py")
    lancer("generate_bulletin_soir.py")
    lancer("sync_diffusion.py")
    print("Journal du Soir OK")

if __name__ == "__main__":
    main()
