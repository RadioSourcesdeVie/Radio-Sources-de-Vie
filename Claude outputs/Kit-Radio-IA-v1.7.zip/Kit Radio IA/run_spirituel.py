#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kit Radio IA - Orchestrateur SPIRITUEL : prières, témoignage, sermon (texte + audio) + synchronisation diffusion.
Chaque sous-partie est activable/désactivable indépendamment via config.MODULES_ACTIFS."""
from _orchestration_commune import log, lancer, actif

def main():
    log("SPIRITUEL")

    types_contenu = []
    if actif("prieres"):
        types_contenu.append("prayer")
    if actif("temoignage"):
        types_contenu.append("testimony")
    if types_contenu:
        lancer("generate_content.py", "--type", "all" if len(types_contenu) == 2 else types_contenu[0])
    else:
        print("Prières et témoignage désactivés (config.MODULES_ACTIFS) — étape ignorée")

    if actif("sermon"):
        lancer("generate_sermon.py")
    else:
        print("Sermon désactivé (config.MODULES_ACTIFS) — étape ignorée")

    if actif("prieres") or actif("temoignage") or actif("sermon"):
        lancer("generate_daily_audio.py")
        lancer("sync_diffusion.py")

    print("Spirituel OK")

if __name__ == "__main__":
    main()
