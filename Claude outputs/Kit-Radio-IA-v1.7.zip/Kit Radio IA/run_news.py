#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kit Radio IA - Orchestrateur NEWS : récupère les flux RSS, génère les résumés audio + synchronisation diffusion.
Désactivable entièrement via config.MODULES_ACTIFS["news_resumes"] = False."""
from _orchestration_commune import log, lancer, actif

def main():
    log("NEWS")
    if not actif("news_resumes"):
        print("Résumés d'actualités désactivés (config.MODULES_ACTIFS) — étape ignorée")
        return
    lancer("fetch_news.py")
    lancer("generate_resumes.py")
    lancer("sync_diffusion.py")
    print("Nouvelles OK")

if __name__ == "__main__":
    main()
