# Kit Radio IA — Langues et voix disponibles

Ce kit fonctionne dans **n'importe quelle langue prise en charge par votre
fournisseur de voix (TTS)**. Changez simplement `STATION_LANGUE` et les voix
dans `config.py` — le texte généré par Claude suivra automatiquement la
langue choisie.

## Obtenir la liste complète et à jour (recommandé)

La liste exacte des voix évolue régulièrement (Microsoft en ajoute). Pour
voir TOUTES les voix disponibles au moment de votre installation :

```
pip install edge-tts
edge-tts --list-voices
```

Cette commande affiche plus de 300 voix, dans plus de 140 langues/variantes.

## Sélection de langues courantes (Edge TTS, gratuit)

Exemples de codes de voix à copier dans `EDGE_VOICES` (config.py) :

| Langue | Code voix (exemples) |
|---|---|
| Français (France) | `fr-FR-DeniseNeural`, `fr-FR-HenriNeural` |
| Français (Belgique) | `fr-BE-CharlineNeural`, `fr-BE-GerardNeural` |
| Français (Canada) | `fr-CA-SylvieNeural`, `fr-CA-AntoineNeural` |
| Français (Suisse) | `fr-CH-ArianaNeural`, `fr-CH-FabriceNeural` |
| Anglais (États-Unis) | `en-US-AriaNeural`, `en-US-GuyNeural` |
| Anglais (Royaume-Uni) | `en-GB-SoniaNeural`, `en-GB-RyanNeural` |
| Anglais (Nigeria) | `en-NG-EzinneNeural`, `en-NG-AbeoNeural` |
| Anglais (Kenya) | `en-KE-AsiliaNeural`, `en-KE-ChilembaNeural` |
| Anglais (Afrique du Sud) | `en-ZA-LeahNeural`, `en-ZA-LukeNeural` |
| Espagnol (Espagne) | `es-ES-ElviraNeural`, `es-ES-AlvaroNeural` |
| Espagnol (Mexique) | `es-MX-DaliaNeural`, `es-MX-JorgeNeural` |
| Portugais (Brésil) | `pt-BR-FranciscaNeural`, `pt-BR-AntonioNeural` |
| Portugais (Portugal) | `pt-PT-RaquelNeural`, `pt-PT-DuarteNeural` |
| Swahili (Kenya) | `sw-KE-ZuriNeural`, `sw-KE-RafikiNeural` |
| Arabe (plus de 15 pays) | ex. `ar-SA-ZariyahNeural`, `ar-EG-SalmaNeural` |

D'autres langues largement couvertes par Edge TTS : allemand, italien,
néerlandais, polonais, roumain, russe, turc, hindi, indonésien, coréen,
japonais, chinois (mandarin/cantonais), vietnamien, et bien d'autres.

## Important : langues NON couvertes par Edge TTS

Vérifié au moment de la rédaction : le **créole haïtien** et le **lingala**
ne font PAS partie des langues Edge TTS. Pour une station en créole ou en
lingala, deux options :
1. Utiliser une voix proche (français ou anglais) en attendant.
2. Passer sur **ElevenLabs**, qui propose un mode multilingue plus flexible
   (clonage de voix compris) — voir `ELEVENLABS_VOICES` dans `config.py`.
   Vérifiez sur elevenlabs.io si la langue exacte est couverte avant d'acheter.

## Fournisseurs payants (si vous voulez sortir des voix Edge TTS gratuites)

- **ElevenLabs** — voix les plus naturelles, clonage de voix possible,
  couverture linguistique large mais variable selon la langue. Payant à l'usage.
- **Google Gemini TTS** — bonne qualité, quota gratuit limité puis payant.
  Voir la documentation Google AI Studio pour la liste des langues couvertes
  au moment de votre installation (elle évolue).

## Comment changer de langue

1. Ouvrez `config.py`.
2. Changez `STATION_LANGUE` (ex: `"anglais"`, `"espagnol"`, `"swahili"`).
3. Mettez à jour les voix dans `EDGE_VOICES` (ou `ELEVENLABS_VOICES` /
   `GEMINI_VOICES` selon votre choix) avec des codes de la langue voulue.
4. Relancez un test (`python generate_content.py --type all`) — le texte ET
   la voix suivront automatiquement la nouvelle langue.
