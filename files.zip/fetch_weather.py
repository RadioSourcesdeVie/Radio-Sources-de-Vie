#!/usr/bin/env python3
"""
fetch_weather.py — Météo Ottawa + Port-au-Prince → weather.json
Radio Sources de Vie Chrétienne

Usage:
    python fetch_weather.py --api-key YOUR_OPENWEATHERMAP_KEY

Obtenir une clé gratuite: https://openweathermap.org/api
"""

import json, sys, argparse
from datetime import datetime
from pathlib import Path

try:
    import requests
except ImportError:
    sys.exit("❌  Installez requests: pip install requests")

BASE = "https://api.openweathermap.org/data/2.5/weather"
CITIES = {
    "ottawa": {"q": "Ottawa,CA", "label": "Ottawa, Canada"},
    "pap":    {"q": "Port-au-Prince,HT", "label": "Port-au-Prince, Haïti"},
}

WEATHER_BLESSINGS = {
    "clear sky":      "Beau ciel — \"Les cieux racontent la gloire de Dieu\" (Ps 19:1)",
    "few clouds":     "Quelques nuages — Dieu est notre refuge par tous les temps",
    "scattered clouds":"Nuages épars — Sa lumière perce toujours les nuages",
    "broken clouds":  "Nuages — Il est notre lumière dans l'obscurité",
    "shower rain":    "Averses — \"Il fera venir la pluie en son temps\" (Dt 11:14)",
    "rain":           "Pluie — Bénédiction du Seigneur sur la terre",
    "thunderstorm":   "Orage — \"L'Éternel fait retentir sa voix\" (Ps 29:3)",
    "snow":           "Neige — Blanche comme neige par Sa grâce (Is 1:18)",
    "mist":           "Brume — Il guide nos pas dans la brume de la vie",
}

def get_blessing(desc):
    for key, blessing in WEATHER_BLESSINGS.items():
        if key in desc.lower():
            return blessing
    return "Que Dieu bénisse cette journée 🙏"

def fetch(api_key, city_key, city_conf):
    url = f"{BASE}?q={city_conf['q']}&appid={api_key}&units=metric&lang=fr"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    d = r.json()
    desc = d["weather"][0]["description"]
    return {
        "label":       city_conf["label"],
        "temp":        d["main"]["temp"],
        "feels_like":  d["main"]["feels_like"],
        "humidity":    d["main"]["humidity"],
        "description": desc.capitalize(),
        "icon":        d["weather"][0]["icon"],
        "wind_kmh":    round(d["wind"]["speed"] * 3.6, 1),
        "blessing":    get_blessing(desc),
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--api-key", required=True, help="Clé API OpenWeatherMap")
    parser.add_argument("--output", default="weather.json")
    args = parser.parse_args()

    result = {"updated": datetime.utcnow().isoformat() + "Z"}

    for key, conf in CITIES.items():
        try:
            result[key] = fetch(args.api_key, key, conf)
            print(f"✅  {conf['label']}: {result[key]['temp']:.0f}°C — {result[key]['description']}")
        except Exception as e:
            print(f"⚠️   {conf['label']}: erreur — {e}")
            result[key] = {"description": "Indisponible", "temp": 0}

    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n💾  Météo sauvegardée → {args.output}")

if __name__ == "__main__":
    main()
