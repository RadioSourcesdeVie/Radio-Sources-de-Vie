#!/usr/bin/env python3
"""
fetch_news.py — Collecte les nouvelles RSS (chrétiennes, Haïti, internationales)
Radio Sources de Vie Chrétienne

Usage:
    python fetch_news.py [--max 5]

Dépendances:
    pip install feedparser requests
"""

import json, sys, argparse
from datetime import datetime
from pathlib import Path
from email.utils import parsedate_to_datetime

try:
    import feedparser, requests
except ImportError:
    sys.exit("❌  pip install feedparser requests")

TODAY = datetime.now().strftime("%Y-%m-%d")

FEEDS = {
    "chretien": [
        {"url": "https://www.christianpost.com/rss/all", "source": "Christian Post"},
        {"url": "https://www.jesus.net/fr/feed/",         "source": "Jesus.net FR"},
        {"url": "https://www.actualite-protestante.com/feed/", "source": "Actualité Protestante"},
        {"url": "https://www.cef.fr/rss/actualites.xml",  "source": "Chrétiens en France"},
    ],
    "haiti": [
        {"url": "https://lenouvelliste.com/rss/", "source": "Le Nouvelliste"},
        {"url": "https://www.loophaiti.com/feed/", "source": "Loop Haïti"},
        {"url": "https://www.alterpresse.org/rss.php", "source": "AlterPresse"},
    ],
    "monde": [
        {"url": "https://rss.rfi.fr/rfi/francais", "source": "RFI"},
        {"url": "https://www.lemonde.fr/rss/une.xml", "source": "Le Monde"},
        {"url": "https://feeds.bbci.co.uk/afrique/rss.xml", "source": "BBC Afrique"},
    ],
}

def fetch_feed(feed_conf, max_items=5):
    """Fetch and parse one RSS feed, return list of article dicts."""
    items = []
    try:
        d = feedparser.parse(feed_conf["url"])
        for entry in d.entries[:max_items]:
            # Parse date
            pub_date = ""
            if hasattr(entry, "published_parsed") and entry.published_parsed:
                import time
                pub_date = datetime(*entry.published_parsed[:6]).isoformat()
            elif hasattr(entry, "published"):
                try:
                    pub_date = parsedate_to_datetime(entry.published).isoformat()
                except Exception:
                    pub_date = entry.get("published", "")

            # Clean description
            desc = entry.get("summary", "")
            # Strip HTML tags
            import re
            desc = re.sub(r"<[^>]+>", "", desc).strip()[:300]

            items.append({
                "title":  entry.get("title", "Sans titre"),
                "link":   entry.get("link", "#"),
                "desc":   desc,
                "date":   pub_date,
                "source": feed_conf["source"],
            })
    except Exception as e:
        print(f"  ⚠️  {feed_conf['source']}: {e}")
    return items

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max", type=int, default=5, help="Articles max par source")
    args = parser.parse_args()

    all_news = {}

    for category, feeds in FEEDS.items():
        print(f"\n📡 Catégorie: {category}")
        articles = []
        for f in feeds:
            items = fetch_feed(f, args.max)
            articles.extend(items)
            print(f"  ✅  {f['source']}: {len(items)} articles")
        # Sort by date (newest first)
        articles.sort(key=lambda x: x.get("date",""), reverse=True)
        all_news[category] = articles[:20]  # Garder les 20 plus récents

    # Save individual category files
    out_dir = Path("content/news")
    out_dir.mkdir(parents=True, exist_ok=True)

    for category, articles in all_news.items():
        out = out_dir / f"{category}_{TODAY}.json"
        out.write_text(json.dumps({
            "category": category,
            "date": TODAY,
            "updated": datetime.utcnow().isoformat() + "Z",
            "articles": articles
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\n💾  {category}: {len(articles)} articles → {out}")

    # Also save a combined "latest.json" for the website
    latest_file = Path("news_latest.json")
    latest_file.write_text(json.dumps({
        "updated": datetime.utcnow().isoformat() + "Z",
        **{k: v[:5] for k, v in all_news.items()}
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n✅  news_latest.json mis à jour")

if __name__ == "__main__":
    main()
