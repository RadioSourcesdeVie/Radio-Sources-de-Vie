#!/usr/bin/env python3
"""
generate_content.py — Génère prière, sermon, témoignage du jour
Radio Sources de Vie Chrétienne

Usage:
    python generate_content.py --api-key YOUR_ANTHROPIC_KEY [--type prayer|sermon|testimony|all]

Dépendances:
    pip install anthropic
"""

import json, sys, argparse
from datetime import datetime
from pathlib import Path

try:
    import anthropic
except ImportError:
    sys.exit("❌  Installez anthropic: pip install anthropic")

TODAY = datetime.now().strftime("%Y-%m-%d")
NOW   = datetime.now().strftime("%H:%M")

PROMPTS = {
    "prayer": {
        "dir": "content/prayers",
        "system": "Tu es un pasteur chrétien évangélique francophone qui s'adresse à la diaspora haïtienne au Canada. Tu écris avec foi, chaleur et espérance.",
        "user": f"""Écris une prière chrétienne pour le {TODAY}.
Réponds UNIQUEMENT en JSON valide, sans aucun texte avant ou après:
{{
  "title": "Prière du {TODAY}",
  "date": "{TODAY}",
  "verse": "Un verset biblique approprié (version Louis Segond)",
  "reference": "Livre Chapitre:Verset",
  "content": "La prière complète (200-300 mots), personnelle et sincère, qui touche le cœur"
}}"""
    },
    "sermon": {
        "dir": "content/sermons",
        "system": "Tu es un prédicateur chrétien évangélique francophone. Tu prêches avec la Bible, avec profondeur spirituelle et clarté pratique.",
        "user": f"""Écris un court sermon pour le {TODAY}.
Réponds UNIQUEMENT en JSON valide:
{{
  "title": "Titre du sermon (inspirant)",
  "date": "{TODAY}",
  "verse": "Texte principal du sermon (Louis Segond)",
  "reference": "Livre Chapitre:Verset",
  "content": "Le sermon (400-500 mots): introduction, 3 points clés, conclusion avec appel"
}}"""
    },
    "testimony": {
        "dir": "content/testimonies",
        "system": "Tu es un chrétien qui partage un témoignage édifiant. Tes histoires sont authentiques, bibliquement fondées, et encouragent la foi.",
        "user": f"""Écris un témoignage chrétien édifiant pour le {TODAY}.
Réponds UNIQUEMENT en JSON valide:
{{
  "title": "Titre du témoignage",
  "date": "{TODAY}",
  "verse": "Un verset qui correspond au témoignage (Louis Segond)",
  "reference": "Livre Chapitre:Verset",
  "content": "Le témoignage (250-350 mots): situation difficile → rencontre avec Dieu → transformation → encouragement"
}}"""
    }
}

def generate(client, content_type):
    cfg = PROMPTS[content_type]
    out_dir = Path(cfg["dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / f"{TODAY}.json"

    if out_file.exists():
        print(f"⏭️   {content_type}: déjà généré pour aujourd'hui ({out_file})")
        return True

    print(f"✍️   Génération du {content_type}...")
    try:
        msg = client.messages.create(
            model="claude-opus-4-5",
            max_tokens=1500,
            system=cfg["system"],
            messages=[{"role": "user", "content": cfg["user"]}]
        )
        raw = msg.content[0].text.strip()
        # Nettoyer les backticks JSON si présents
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
            raw = raw.strip()
        data = json.loads(raw)
        out_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"✅  {content_type} sauvegardé → {out_file}")
        return True
    except json.JSONDecodeError as e:
        print(f"❌  Erreur JSON pour {content_type}: {e}")
        print(f"    Réponse brute: {raw[:200]}...")
        return False
    except Exception as e:
        print(f"❌  Erreur {content_type}: {e}")
        return False

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--api-key", required=True, help="Clé API Anthropic")
    parser.add_argument("--type", choices=["prayer","sermon","testimony","all"], default="all")
    args = parser.parse_args()

    client = anthropic.Anthropic(api_key=args.api_key)

    types = ["prayer","sermon","testimony"] if args.type == "all" else [args.type]
    success = 0
    for t in types:
        if generate(client, t):
            success += 1

    print(f"\n🙏  {success}/{len(types)} contenus générés pour {TODAY}")

if __name__ == "__main__":
    main()
