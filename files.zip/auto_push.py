#!/usr/bin/env python3
"""
auto_push.py — Script maître: génère tout le contenu et pousse vers GitHub
Radio Sources de Vie Chrétienne

Usage:
    python auto_push.py --owm-key OWM_KEY --anthropic-key CLAUDE_KEY
    python auto_push.py --owm-key OWM_KEY --anthropic-key CLAUDE_KEY --skip-content
    python auto_push.py --help

Planifier (Windows Task Scheduler):
    Matin  (06:00): python auto_push.py --owm-key KEY --anthropic-key KEY
    Midi   (12:00): python auto_push.py --owm-key KEY --skip-content
    Soir   (18:00): python auto_push.py --owm-key KEY --skip-content

Dépendances:
    pip install requests feedparser anthropic
"""

import sys, os, subprocess, argparse
from datetime import datetime
from pathlib import Path

REPO_ROOT = Path(__file__).parent.resolve()
TODAY     = datetime.now().strftime("%Y-%m-%d")
NOW_FR    = datetime.now().strftime("%d/%m/%Y à %Hh%M")

def run(cmd, cwd=None, check=True):
    """Exécute une commande shell et affiche la sortie."""
    print(f"\n$ {cmd}")
    result = subprocess.run(
        cmd, shell=True, cwd=cwd or REPO_ROOT,
        capture_output=False, text=True
    )
    if check and result.returncode != 0:
        print(f"⚠️  La commande a retourné le code {result.returncode}")
    return result.returncode == 0

def step(msg):
    print(f"\n{'─'*50}")
    print(f"  {msg}")
    print(f"{'─'*50}")

def main():
    parser = argparse.ArgumentParser(description="Radio Sources de Vie — Publication automatique")
    parser.add_argument("--owm-key",       required=True,  help="Clé OpenWeatherMap")
    parser.add_argument("--anthropic-key", default=None,   help="Clé Anthropic (pour contenu quotidien)")
    parser.add_argument("--skip-content",  action="store_true", help="Ne pas régénérer prière/sermon/témoignage")
    parser.add_argument("--skip-push",     action="store_true", help="Ne pas pousser vers GitHub")
    args = parser.parse_args()

    print(f"""
╔══════════════════════════════════════════╗
║  📻  Radio Sources de Vie Chrétienne    ║
║  🗓️   Publication: {NOW_FR}          ║
╚══════════════════════════════════════════╝
""")

    # ── 1. MÉTÉO ──────────────────────────────────────────────────────────────
    step("🌡️  Étape 1/4 — Météo Ottawa + Port-au-Prince")
    run(f'python fetch_weather.py --api-key "{args.owm_key}"')

    # ── 2. NOUVELLES RSS ──────────────────────────────────────────────────────
    step("📰  Étape 2/4 — Collecte des nouvelles RSS")
    run("python fetch_news.py --max 5")

    # ── 3. CONTENU SPIRITUEL ──────────────────────────────────────────────────
    if not args.skip_content:
        if args.anthropic_key:
            step("🙏  Étape 3/4 — Génération prière/sermon/témoignage")
            run(f'python generate_content.py --api-key "{args.anthropic_key}" --type all')
        else:
            print("\n⏭️   Étape 3/4 ignorée (--anthropic-key non fourni)")
    else:
        print("\n⏭️   Étape 3/4 ignorée (--skip-content)")

    # ── 4. GIT PUSH ────────────────────────────────────────────────────────────
    if not args.skip_push:
        step("🚀  Étape 4/4 — Publication GitHub")

        # Vérifier qu'on est dans un dépôt git
        if not (REPO_ROOT / ".git").exists():
            print("⚠️   Pas de dépôt git trouvé. Initialisez d'abord avec:")
            print("     git init && git remote add origin https://github.com/RadioSourcesdeVie/Radio-Sources-de-Vie.git")
        else:
            run("git add -A")
            commit_msg = f"📻 Mise à jour automatique — {NOW_FR}"
            run(f'git commit -m "{commit_msg}"')
            ok = run("git push origin main", check=False)
            if not ok:
                print("  ℹ️  Essai avec 'master' au lieu de 'main'...")
                run("git push origin master", check=False)
    else:
        print("\n⏭️   Étape 4/4 ignorée (--skip-push)")

    # ── RÉSUMÉ ────────────────────────────────────────────────────────────────
    print(f"""
╔══════════════════════════════════════════╗
║  ✅  Publication terminée!              ║
║  🌐  Site: radiosourcesdevie.github.io  ║
║  📡  Stream: stream.zeno.fm/sgnhqhl2oeevv ║
║  "Que Sa Parole aille jusqu'aux extrémités" ║
╚══════════════════════════════════════════╝
""")

if __name__ == "__main__":
    main()
